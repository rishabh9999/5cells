## Welcome to Context Innovation Lab 
## Author : Dr.Thyagaraju G S
## Problem : Python-KNN-Algorithm
## Reference : ML by Tom Mitchell

